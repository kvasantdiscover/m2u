package com.tguzik.m2u.data.junit;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias( "error" )
public class Error extends Failure {

}
