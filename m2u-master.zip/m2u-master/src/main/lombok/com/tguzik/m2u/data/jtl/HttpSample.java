package com.tguzik.m2u.data.jtl;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias( impl = HttpSample.class, value = "httpSample" )
public class HttpSample extends BaseSample {
    // no changes needed
}
